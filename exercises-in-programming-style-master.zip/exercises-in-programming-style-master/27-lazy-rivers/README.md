Style #27
==============================

Constraints:

- Data comes to functions in streams, rather than as a complete whole all at at once
- Functions are filters / transformers from one kind of data stream to another

Possible names:

- Lazy rivers
- Data streams
- Dataflow
- Data generators
