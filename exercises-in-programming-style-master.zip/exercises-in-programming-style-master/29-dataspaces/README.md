Style #29
==============================

Constraints:

- Existence of one or more units that execute concurrently

- Existence of one or more data spaces where concurrent units store and
  retrieve data

- No direct data exchanges between the concurrent units, other than via the data spaces

Possible names:

- Dataspaces
- Linda

