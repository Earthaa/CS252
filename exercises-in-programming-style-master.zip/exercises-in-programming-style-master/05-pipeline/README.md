Style #5
==============================

Constraints:

- Larger problem decomposed in functional abstractions. Functions, according to Mathematics, are relations from inputs to outputs.
- Larger problem solved as a pipeline of function applications

Possible names:

- Candy factory
- Functional
- Pipeline
