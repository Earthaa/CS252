Style #16
==============================

Constraints:

- The problem is decomposed using some form of abstraction (procedures, functions, objects, etc.)

- The abstractions have access to information about themselves, although they cannot modify that information


Possible names:

- Introspective
- Navel-gazing

