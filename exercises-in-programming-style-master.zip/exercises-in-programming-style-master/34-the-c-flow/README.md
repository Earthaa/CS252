Style #34
==============================

Constraints:

- No returns before the end of procedures or functions

- No breaks or continues in iterations

Possible names:

- The flow


