Style #26
==============================

Constraints:

- The problem is modeled like a spreadsheet, with columns of data and formulas

- Some data depends on other data according to formulas. When data
  changes, the dependent data also changes automatically.


Possible names:

- Spreadsheet
- Dataflow
- Active data
