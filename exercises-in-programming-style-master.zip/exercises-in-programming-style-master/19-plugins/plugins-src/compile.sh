python -m compileall .
cp *.pyc ../plugins
