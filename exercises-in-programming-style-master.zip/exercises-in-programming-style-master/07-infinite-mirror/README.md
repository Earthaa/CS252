Style #7
==============================

Constraints:

- All, or a significant part, of the problem is modelled by
  induction. That is, specify the base case (n_0) and then the n+1
  rule

Possible names:

- Infinite mirror
- Inductive
- Recursive

