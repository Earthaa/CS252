Style #3
==============================

Constraints:

- No abstractions
- No use of library functions

Possible names:

- Monolith
- Labyrinth
- Brain dump
