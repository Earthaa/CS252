Style #6
==============================

Constraints:

- As few lines of code as possible

Possible names:

- Code golf
- Try hard
