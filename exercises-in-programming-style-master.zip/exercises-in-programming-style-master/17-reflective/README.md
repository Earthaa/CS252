Style #17
==============================

Constraints:

- The program has access to information about itself, i.e. introspection

- The program can modify itself -- adding more abstractions, variables, etc. at run-time


Possible names:

- Reflective, as in "I see me, so I can change myself"
- Metaprogramming style
- Self-referential

