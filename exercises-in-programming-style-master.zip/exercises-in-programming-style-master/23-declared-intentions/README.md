Style #23
==============================

Constraints:

- Existence of a run-time typechecker

- Procedures and functions declare what types of arguments they expect

- If callers send arguments of types that are't expected, the
  procedures/functions are not executed


Possible names:

- declared intentions
- "You've been warned!"

